package com.ct.utilities;


//import org.apache.pdfbox.cos.COSDocument;
//import org.apache.pdfbox.io.RandomAccessRead;
//import org.apache.pdfbox.pdfparser.PDFParser;
//import org.apache.pdfbox.pdmodel.PDDocument;
//import org.apache.pdfbox.text.PDFTextStripper;
//import org.junit.Assert;
//
//import java.io.File;
//import java.io.FileInputStream;
//import java.io.IOException;

public class PDFReader {

//public static void pdfReader () throws IOException {
//   File file = new File("location of pdf file");
//   FileInputStream fileInputStream = new FileInputStream(file);
//
//    PDFParser parser = new PDFParser((RandomAccessRead) fileInputStream);
//    parser.parse();
//
//    COSDocument cosDocument = parser.getDocument();
//    PDDocument pdDocument = new PDDocument(cosDocument);
//
//    PDFTextStripper pdfTextStripper = new PDFTextStripper();
//
//    String data = pdfTextStripper.getText(pdDocument);
//    System.out.println(data);
//
//    String loanID = "uniqueLoanID" ;
//    Assert.assertTrue(data.contains(loanID));
//
//    cosDocument.close();
//    pdDocument.close();
//
//    System.out.println("LoanID is same in Email and DB and confirmation page");
//}

}
