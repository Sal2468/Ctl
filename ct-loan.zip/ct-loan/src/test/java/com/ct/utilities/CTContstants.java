package com.ct.utilities;

public class CTContstants {
	public static final String DEV_URL = "http://cybertekschool.com/ctl.dev";
	public static final String QA_URL = "http://cybertekschool.com/ctl.qa";
	
}
